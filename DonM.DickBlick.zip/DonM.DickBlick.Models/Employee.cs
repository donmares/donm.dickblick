﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace DonM.DickBlick.Models
{
    public class Employee
    {
        public long EmployeeId { get; set; }
        [Required]
        [StringLength(64, ErrorMessage = "Name is required")]
        public string Name { get; set; }
    }
}
