﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace DonM.DickBlick.Models
{
    public class Product
    {
        [BindNever]
        public long ProductId { get; set; }
        
        public string ImageUrl { get; set; }

        public string ImageThumbnailUrl { get; set; }
        [Required]
        [StringLength(64, ErrorMessage = "Name is required")]
        public string Name { get; set; }
        [Required]
        [StringLength(512, ErrorMessage = "Description is required")]
        public string Description { get; set; }
        [Required]
        [RegularExpression(@"^\d+\.\d{0,2}$", ErrorMessage = "Price is required")]
        public decimal Price { get; set; }

        public Enums.ProductType ProductType { get; set; }

        public IEnumerable<Employee> Buyers { get; set; }
    }
}
