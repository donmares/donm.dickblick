﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DonM.DickBlick.Models.Enums
{
    public enum ProductType
    {
        Pencil=1
    }
}
