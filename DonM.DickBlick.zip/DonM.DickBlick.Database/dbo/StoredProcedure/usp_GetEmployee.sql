﻿CREATE PROCEDURE [dbo].[usp_GetEmployee]
	@pEmployeeID	BIGINT 	
AS
BEGIN
	SELECT Employee_ID, Name
	FROM Employee
	WHERE Employee_ID = @pEmployeeID
	  OR ISNULL(@pEmployeeID,0) = 0 
	ORDER BY Name;
END;
GO
