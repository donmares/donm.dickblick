﻿CREATE PROCEDURE [dbo].[usp_GetProduct]
	@pProductID	BIGINT 	
AS
BEGIN
	SELECT Product_ID, Product_Type_ID, Name, Description, Price, Image_Url, Image_Thumbnail_Url
	FROM Product
	WHERE Product_ID = @pProductID
	  OR ISNULL(@pProductID,0) = 0 
	ORDER BY Name;
END;
GO
