﻿CREATE PROCEDURE [dbo].[usp_GetProductBuyerByProduct]
	@pProductID		BIGINT
AS
BEGIN
	SELECT pb.Product_Buyer_Id, pb.Product_ID, p.Name Product_Name, pb.Employee_ID, e.name employee_Name
	FROM Product_Buyer pb
	  INNER JOIN Product p ON pb.Product_ID = p.Product_ID
	  INNER JOIN Employee e ON pb.employee_ID = e.employee_ID
	WHERE pb.Product_ID = @pProductID
	  OR ISNULL(@pProductID,0) = 0 
	ORDER BY p.Name, e.name;
END;
GO

