﻿CREATE PROCEDURE [dbo].[usp_DeleteProductBuyerByProduct]
	@pProductID		BIGINT
AS
BEGIN
	DELETE Product_Buyer
	WHERE Product_ID = @pProductID;
END
GO
