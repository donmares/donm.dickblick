﻿CREATE PROCEDURE [dbo].[usp_InsertEmployee]
	@pName			varchar(64),
	@poEmployeeID	BIGINT OUTPUT
AS
BEGIN
	INSERT INTO dbo.Employee(Name)
	VALUES (@pName);

	SELECT @poEmployeeID = SCOPE_IDENTITY();
END;
GO
