﻿CREATE PROCEDURE [dbo].[usp_DeleteProduct]
	@pProductID		BIGINT
AS
BEGIN
	DELETE Product
	WHERE Product_Id = @pProductID;
END;
GO

