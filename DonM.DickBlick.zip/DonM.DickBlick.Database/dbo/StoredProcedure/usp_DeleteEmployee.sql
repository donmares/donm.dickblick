﻿CREATE PROCEDURE [dbo].[usp_DeleteEmployee]
	@pEmployeeID		BIGINT
AS
BEGIN
	DELETE Employee
	WHERE Employee_ID = @pEmployeeID;
END;
GO

