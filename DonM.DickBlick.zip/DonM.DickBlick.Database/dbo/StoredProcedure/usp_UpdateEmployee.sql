﻿CREATE PROCEDURE [dbo].[usp_UpdateEmployee]
	@pEmployeeID	BIGINT,
	@pName			varchar(64)
AS
BEGIN
	UPDATE dbo.Employee
	SET Name = @pName
	WHERE Employee_id = @pEmployeeID;
END;
GO
