﻿CREATE PROCEDURE [dbo].[usp_UpdateProduct]
	@pProductID			BIGINT,
	@pProductTypeID		INT,
	@pName				VARCHAR(64),
	@pDescription		VARCHAR(512),
	@pPrice				DECIMAL(6,2),
    @pImageUrl			VARCHAR(64),
	@pImageThumbnailUrl	VARCHAR(64)
AS
BEGIN
	UPDATE dbo.Product 
	SET Product_Type_ID = @pProductTypeID,
		Name = @pName,
		Description = @pDescription,
		Price = @pPrice,
		Image_Url = @pImageUrl,
		Image_Thumbnail_url = @pImageThumbnailUrl
	WHERE Product_ID = @pProductID;
END;
GO