﻿CREATE PROCEDURE [dbo].[usp_InsertProduct]
	@pProductTypeID		INT,
	@pName				VARCHAR(64),
	@pDescription		VARCHAR(512),
	@pPrice				DECIMAL(6,2),
    @pImageUrl			VARCHAR(64),
	@pImageThumbnailUrl	VARCHAR(64),
	@poProductID		BIGINT OUTPUT
AS
BEGIN
	INSERT INTO dbo.Product (Product_Type_ID, Name, Description, Price, Image_Url, Image_thumbnail_url)
	VALUES (@pProductTypeID, @pName, @pDescription, @pPrice, @pImageUrl, @pImageThumbnailUrl);

	SELECT @poProductID = SCOPE_IDENTITY();
END;
GO