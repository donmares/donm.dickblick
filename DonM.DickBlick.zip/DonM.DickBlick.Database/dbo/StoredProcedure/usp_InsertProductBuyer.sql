﻿CREATE PROCEDURE [dbo].[usp_InsertProductBuyer]
	@pProductID			BIGINT,
	@pEmployeeID		BIGINT
AS
BEGIN
    DECLARE @vProductBuyerID BIGINT;

	SELECT @vProductBuyerID = Product_Buyer_ID
	FROM dbo.Product_Buyer
	WHERE product_ID = @pProductID
	  AND employee_ID = @pEmployeeID;

	IF ISNULL(@vProductBuyerID, 0) = 0
	begin
		INSERT INTO dbo.Product_buyer(Product_Id, Employee_Id)
		VALUES (@pProductID, @pEmployeeID);
	end;
END;
GO
