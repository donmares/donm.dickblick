﻿CREATE PROCEDURE [dbo].[usp_GetProductType]
	@pProductTypeID	int
AS
	SELECT Product_Type_ID, Name
	FROM Product_Type
	WHERE Product_Type_ID = @pProductTypeID or ISNULL(@pProductTypeID,0) = 0 
	ORDER BY Name;
RETURN 0
