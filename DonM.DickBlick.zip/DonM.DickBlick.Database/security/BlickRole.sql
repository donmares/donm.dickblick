﻿CREATE ROLE [BlickRole] AUTHORIZATION db_Owner;
GO

exec sp_addRoleMember 'db_owner', 'BlickRole';
