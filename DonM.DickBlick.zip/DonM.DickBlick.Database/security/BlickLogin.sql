﻿CREATE LOGIN [BlickUser] WITH PASSWORD = 'Password1$'
