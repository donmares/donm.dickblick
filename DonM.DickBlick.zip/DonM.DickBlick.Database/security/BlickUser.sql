﻿CREATE USER [BlickUser]
	FOR LOGIN BlickUser
	WITH DEFAULT_SCHEMA = dbo

GO

GRANT CONNECT TO [BlickUser]
GO

exec sp_addRoleMember 'BlickRole', 'BlickUser';