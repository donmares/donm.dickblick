﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

DECLARE @ScriptStartTime datetime, @CurrentVersion DECIMAL(10,2), @ReleaseVersion VARCHAR(7)
SET @ScriptStartTime = GETDATE()

PRINT 'POST DEPLOYMENT START TIME: ' + CONVERT(VARCHAR(30), GETDATE(), 109);

	:r "..\Init\Product_Type_init.sql"
	:r "..\Init\employee_init.sql"
	:r "..\Init\product_init.sql"
	:r "..\Init\product_Buyer_init.sql"

PRINT 'POST DEPLOYMENT END TIME: ' + CONVERT(VARCHAR(30), GETDATE(), 109)

