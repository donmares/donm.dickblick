﻿PRINT 'BEGIN Init Data: Product_Buyer';

IF OBJECT_ID('initProductBuyer') IS NOT NULL
	DROP PROCEDURE initProductBuyer;
GO

CREATE PROCEDURE initProductBuyer 
(  
    @pID			BIGINT,
	@pProductID		BIGINT,
	@pEmployeeID	BIGINT
)  
AS  
BEGIN  
    DECLARE @vID BIGINT;

	SELECT @vID = Product_Buyer_Id
	FROM Product_Buyer
	WHERE Product_Buyer_Id = @pID;
    
	IF ISNULL(@vID, 0) = 0
	BEGIN
		SET IDENTITY_INSERT Product_Buyer ON;

		INSERT INTO Product_Buyer (product_Buyer_Id, product_id, employee_id)
		VALUES (@pID, @pProductID, @pEmployeeID);

		SET IDENTITY_INSERT Product_Buyer OFF;
	END;
	ELSE
	BEGIN
		UPDATE Product_Buyer
		SET Product_ID = @pProductID,
			Employee_ID = @pEmployeeID
		WHERE Product_Buyer_Id = @pID;
	END;
END;  
GO   

EXEC initProductBuyer 11, 1, 1;
EXEC initProductBuyer 12, 2, 1;
EXEC initProductBuyer 13, 3, 1;
EXEC initProductBuyer 14, 4, 1;
EXEC initProductBuyer 21, 1, 2;
EXEC initProductBuyer 22, 2, 2;
EXEC initProductBuyer 35, 5, 3;
EXEC initProductBuyer 36, 6, 3;
GO

IF OBJECT_ID('initProductBuyer') IS NOT NULL
	DROP PROCEDURE initProductBuyer;
GO

PRINT 'END Init Data: Product_Buyer';
