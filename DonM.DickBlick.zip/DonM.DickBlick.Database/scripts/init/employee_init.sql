﻿PRINT 'BEGIN Init Data: Employee';

IF OBJECT_ID('initEmployee') IS NOT NULL
	DROP PROCEDURE initEmployee;
GO

CREATE PROCEDURE initEmployee 
(  
    @pID			BIGINT,
	@pName			VARCHAR(64)
)  
AS  
BEGIN  
    DECLARE @vID BIGINT;

	SELECT @vID = Employee_ID
	FROM Employee
	WHERE Employee_ID = @pID;
    
	IF ISNULL(@vID, 0) = 0
	BEGIN
		SET IDENTITY_INSERT Employee ON;

		INSERT INTO Employee (Employee_ID, Name)
		VALUES (@pID, @pName);

		SET IDENTITY_INSERT Employee OFF;
	END;
	ELSE
	BEGIN
		UPDATE Employee
		SET Name = @pName
		WHERE Employee_ID = @pID;
	END;
END;  
GO   

EXEC initEmployee 1, 'Jim';
EXEC initEmployee 2, 'Jill';
EXEC initEmployee 3, 'Jack';

GO

IF OBJECT_ID('initEmployee') IS NOT NULL
	DROP PROCEDURE initEmployee;
GO

PRINT 'END Init Data: Employee';
