﻿PRINT 'BEGIN Init Data: Product';

IF OBJECT_ID('initProduct') IS NOT NULL
	DROP PROCEDURE initProduct;
GO

CREATE PROCEDURE initProduct 
(  
    @pID				BIGINT,
	@pProductTypeID		INT,
	@pName				VARCHAR(64),
	@pPrice				DECIMAL(6,2),
	@pDescription		VARCHAR(512),
	@pImageUrl			VARCHAR(64),
	@pImageThumbnailUrl	VARCHAR(64)
)  
AS  
BEGIN  
    DECLARE @vID INT;

	SELECT @vID = Product_ID
	FROM Product
	WHERE Product_ID = @pID;
    
	IF ISNULL(@vID, 0) = 0
	BEGIN
		SET IDENTITY_INSERT Product ON;

		INSERT INTO Product (Product_ID, Product_Type_ID, Name, Description, Price, Image_Url, Image_thumbnail_Url)
		VALUES (@pID, @pProductTypeID, @pName, @pDescription, @pPrice, @pImageUrl, @pImageThumbnailUrl);

		SET IDENTITY_INSERT Product OFF;
	END;
	ELSE
	BEGIN
		UPDATE Product
		SET Product_Type_ID = @pProductTypeID,
			Name = @pName,
			Description = @pDescription, 
			Price = @pPrice,
			Image_Url = @pImageUrl,
			Image_Thumbnail_Url = @pImageThumbnailUrl
		WHERE Product_ID = @pID;
	END;
END;  
GO   

EXEC initProduct 1, 1, '#2 Writing Pencil', 1.95, 'Prized for its tight wood grain, California Incense Cedar is regarded as the best wood for pencil production, which is used to make this No. 2 writing pencil!<br><br>These smooth - sharpening pencils feature a hexagonal casing and a yellow enamel finish.<br><br>Made in the USA.', '/images/20341-4002-3ww-l.jpg', '/images/20341-4002-2ww-m.jpg';
EXEC initProduct 2, 1, 'Pentel Graph Gear 800 Mechanical Drafting Pencils', 8.59, 'A 4 mm fixed sleeve protects the lead and makes the GraphGear 800 ideal for use with rulers and templates. It''s guaranteed TO scan just LIKE a NO. 2 pencil.<br><br>The metal grip IS inlaid WITH soft, latex-FREE pads, AND the barrel IS perfectly balanced FOR more CONTROL WHEN writing.The metal clip withstands repeated USE, AND the cap conceals AND protects the eraser BETWEEN uses.', '/images/20687-1003-1-3ww-l.jpg', '/images/20687-1003-1-2ww-m.jpg';
EXEC initProduct 3, 1, 'Coloreed Pencil Set', 17.49, 'Ideal for drawing, illustrating, and coloring, these richly colored pencils feature brilliantly balanced shades for superior blending. Long lasting, thick 3.8 mm leads are encased in round, lacquered California cedar casings. For easy identification, the exterior of each pencil is colored to match the core and the color name is printed on both ends.<bl><bl><ul>These pre-sharpened pencils feature:<li>Smooth color lay-down</li><li>Highly pigmented, fade-resistant leads</li><li>91 artist-quality colors sold separately</li></ul>', '/images/22063-0249-2-3ww-l.jpg', '/images/22063-0249-2-2ww-m.jpg';
EXEC initProduct 4, 1, 'Derwent Inktense Pencils', 17.99, 'Derwent Inktense Pencils are as versatile as watercolor pencils, but with a firmer texture that allows them to perform with the brilliant intensity of traditional pen-and-ink. These pencils are available in strong, vibrant colors which work beautifully on their own or can be mixed together to create rich, subtle tones. The pure, clean colors are perfect for bold expressive drawings, including fashion illustration, landscapes, greeting cards, and more.<br><br>Inktense pencils can be used dry for rich, intense color or washed out with a little water to create a vivid translucent effect.Once dry, the color is permanent and can be worked over with other media.Pencils are pre - sharpened.', '/images/22051-1006-1-3ww-l.jpg', '/images/22051-1006-1-2ww-m.jpg';
EXEC initProduct 5, 1, 'Charcoal Drawing Set', 22.83, 'Cretacolor''s "Black Box" Charcoal Drawing Set is an outstanding value, offering 20 different charcoal related drawing materials, all made in Austria:', '/images/20445-1009-3-3ww-l.jpg', '/images/20445-1009-3-2ww-m.jpg';
EXEC initProduct 6, 1, 'Blick Studio Drawing Pencils', 10.99, 'Create dramatic effects in your illustrations, drawings, and sketches with Blick Studio Drawing Pencils. Their professional-quality graphite leads are lightfast and clean-erasing, and they offer high opacity.<br/><br/>Every pencil features a hexagonal lacquered cedar casing to prevent it from rolling off surfaces. The hardness grade is printed on all six sides for quick reference.', '/images/22220-2009-3-3ww-l.jpg', '/images/22220-2009-3-2ww-m.jpg';

GO

IF OBJECT_ID('initProduct') IS NOT NULL
	DROP PROCEDURE initProduct;
GO

PRINT 'END Init Data: Product';
