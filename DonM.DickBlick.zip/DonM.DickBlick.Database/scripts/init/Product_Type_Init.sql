﻿PRINT 'BEGIN Init Data: Product_Type';

IF OBJECT_ID('initProductType') IS NOT NULL
	DROP PROCEDURE initProductType;
GO

CREATE PROCEDURE initProductType 
(  
    @pID			BIGINT,
	@pName			VARCHAR(64),
	@pDescription	VARCHAR(256)
)  
AS  
BEGIN  
    DECLARE @vID BIGINT;

	SELECT @vID = Product_Type_ID
	FROM Product_Type
	WHERE Product_Type_ID = @pID;
    
	IF ISNULL(@vID, 0) = 0
	BEGIN
		INSERT INTO Product_Type (Product_Type_ID, Name, Description)
		VALUES (@pID, @pName, @pDescription);
	END;
	ELSE
	BEGIN
		UPDATE Product_Type
		SET Name = @pName,
			Description = @pDescription
		WHERE Product_Type_ID = @pID;
	END;
END;  
GO   

EXEC initProductType 1, 'Pencils', 'could have a bunch of categories and types but keeping this simple with one product type';

GO

IF OBJECT_ID('initProductType') IS NOT NULL
	DROP PROCEDURE initProductType;
GO

PRINT 'END Init Data: Product_Type';
