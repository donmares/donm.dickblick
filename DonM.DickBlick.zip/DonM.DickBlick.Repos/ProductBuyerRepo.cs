﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;
using DonM.DickBlick.Repos.Contracts;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
namespace DonM.DickBlick.Repos
{
    public class ProductBuyerRepo : IProductBuyerRepo 
    {
        private IConfiguration _config;

        public ProductBuyerRepo(IConfiguration config)
        {
            _config = config;
        }

        IEnumerable<Employee> IProductBuyerRepo.GetByProductId(long productId)
        {
            List<Employee> listEmployee = new List<Employee>();

            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_GetProductBuyerByProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductId", productId);
                    conn.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Employee employee = new Employee();

                            employee.EmployeeId = long.Parse(reader["Employee_id"].ToString());
                            employee.Name = reader["Employee_Name"].ToString();

                            listEmployee.Add(employee);
                        }
                    }
                    else
                        return null;

                    reader.Close();
                }
            }
            return listEmployee;
        }

        public void Insert(long productId, long EmployeeId)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_InsertProductBuyer"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductId", productId);
                    command.Parameters.AddWithValue("@pEmployeeId", EmployeeId);

                    conn.Open();

                    command.ExecuteNonQuery();
                }
            }
        }

        public void DeleteByProduct(long productId)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_DeleteProductBuyerByProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductId", productId);

                    conn.Open();

                    command.ExecuteNonQuery();

                }
            }
        }
    }
}
