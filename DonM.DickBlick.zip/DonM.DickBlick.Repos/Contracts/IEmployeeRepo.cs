﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;

namespace DonM.DickBlick.Repos.Contracts
{
    public interface IEmployeeRepo
    {
        IEnumerable<Employee> GetAllEmployees();
        Models.Employee GetEmployeeById(long employeeId);
        void Insert(Employee employee);
        void Update(Employee employee);
        void Delete(long id);
    }
}
