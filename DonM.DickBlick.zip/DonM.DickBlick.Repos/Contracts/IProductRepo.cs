﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;

namespace DonM.DickBlick.Repos.Contracts
{
    public interface IProductRepo
    {
        IEnumerable<Product> GetAllProducts();
        Models.Product GetProductById(long productId);
        void Insert(Product product);
        void Update(Product product);
        void Delete(long id);
    }
}
