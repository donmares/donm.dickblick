﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;

namespace DonM.DickBlick.Repos.Contracts
{
    public interface IProductBuyerRepo
    {
        IEnumerable<Employee> GetByProductId(long productId);
        void Insert(long productId, long employeeId);
        void DeleteByProduct(long productId);
    }
}
