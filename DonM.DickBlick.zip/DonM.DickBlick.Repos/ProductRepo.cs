﻿using System;
using System.Collections.Generic;
using DonM.DickBlick.Models;
using DonM.DickBlick.Repos.Contracts;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace DonM.DickBlick.Repos
{
    public class ProductRepo : IProductRepo
    {
        private IConfiguration _config;
        private IProductBuyerRepo _productBuyerRepo;

        public ProductRepo(IConfiguration config, IProductBuyerRepo productBuyerRepo)
        {
            _config = config;
            _productBuyerRepo = productBuyerRepo;
        }

        IEnumerable<Product> IProductRepo.GetAllProducts()
        {
            List<Product> listProducts = new List<Product>();

            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_GetProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductId", 0);
                    conn.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Product product = new Product();

                            product.ProductId = long.Parse(reader["Product_id"].ToString());
                            product.Name = reader["Name"].ToString();
                            product.Description = reader["Description"].ToString();
                            product.Price = decimal.Parse(reader["Price"].ToString());
                            product.ImageUrl = reader["image_url"].ToString();
                            product.ImageThumbnailUrl = reader["image_thumbnail_url"].ToString();
                            product.ProductType = (Models.Enums.ProductType)int.Parse(reader["product_Type_ID"].ToString());
                            product.Buyers = _productBuyerRepo.GetByProductId(product.ProductId);

                            listProducts.Add(product);
                        }
                    }
                    else
                        return null;

                    reader.Close();
                }
            }
            return listProducts;
        }

        Product IProductRepo.GetProductById(long productId)
        {
            Product product = new Product();

            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_GetProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductId", productId);
                    conn.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        { 
                            product.ProductId = long.Parse(reader["Product_id"].ToString());
                            product.Name = reader["Name"].ToString();
                            product.Description = reader["Description"].ToString();
                            product.Price = decimal.Parse(reader["Price"].ToString());
                            product.ImageUrl = reader["image_url"].ToString();
                            product.ImageThumbnailUrl = reader["image_thumbnail_url"].ToString();
                            product.ProductType = (Models.Enums.ProductType)int.Parse(reader["product_Type_ID"].ToString());
                            product.Buyers = _productBuyerRepo.GetByProductId(product.ProductId);
                        }
                    }
                    else
                        return null;

                    reader.Close();
                }
            }
            return product;
        }

        public void Insert(Product product)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_InsertProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pName", product.Name);
                    command.Parameters.AddWithValue("@pDescription", product.Description);
                    command.Parameters.AddWithValue("@pPrice", product.Price);
                    command.Parameters.AddWithValue("@pImageUrl", product.ImageUrl);
                    command.Parameters.AddWithValue("@pImageThumbnailUrl", product.ImageThumbnailUrl);
                    command.Parameters.AddWithValue("@pProductTypeId", product.ProductType.GetHashCode());

                    SqlParameter outParm = new SqlParameter();
                    outParm.Direction = ParameterDirection.Output;
                    outParm.ParameterName = "@poProductID";
                    outParm.DbType = DbType.Int64;
                    command.Parameters.Add(outParm);

                    conn.Open();

                    command.ExecuteNonQuery();

                    product.ProductId = long.Parse(command.Parameters["@poProductID"].Value.ToString());
                    
                }
                _productBuyerRepo.Insert(product.ProductId, product.Buyers.First().EmployeeId);
            }
        }

        public void Update(Product product)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_UpdateProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductID", product.ProductId);
                    command.Parameters.AddWithValue("@pName", product.Name);
                    command.Parameters.AddWithValue("@pDescription", product.Description);
                    command.Parameters.AddWithValue("@pPrice", product.Price);
                    command.Parameters.AddWithValue("@pImageUrl", product.ImageUrl);
                    command.Parameters.AddWithValue("@pImageThumbnailUrl", product.ImageThumbnailUrl);
                    command.Parameters.AddWithValue("@pProductTypeId", product.ProductType.GetHashCode());

                    conn.Open();

                    command.ExecuteNonQuery();

                }
            }
            _productBuyerRepo.Insert(product.ProductId, product.Buyers.First().EmployeeId);
        }

        public void Delete(long productId)
        {
            _productBuyerRepo.DeleteByProduct(productId);
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_DeleteProduct"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pProductID", productId);

                    conn.Open();

                    command.ExecuteNonQuery();

                }
            }
        }
    }
}
