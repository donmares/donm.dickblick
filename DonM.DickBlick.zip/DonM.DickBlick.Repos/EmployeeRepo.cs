﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;
using DonM.DickBlick.Repos.Contracts;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace DonM.DickBlick.Repos
{
    public class EmployeeRepo : IEmployeeRepo
    {
        private IConfiguration _config;

        public EmployeeRepo(IConfiguration config)
        {
            _config = config;
        }

        IEnumerable<Employee> IEmployeeRepo.GetAllEmployees()
        {
            List<Employee> listEmployees = new List<Employee>();

            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_GetEmployee"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pEmployeeId", 0);
                    conn.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Employee employee = new Employee();

                            employee.EmployeeId = long.Parse(reader["Employee_id"].ToString());
                            employee.Name = reader["Name"].ToString();

                            listEmployees.Add(employee);
                        }
                    }
                    else
                        return null;

                    reader.Close();
                }
            }
            return listEmployees;
        }

        Employee IEmployeeRepo.GetEmployeeById(long employeeId)
        {
            Employee employee = new Employee();

            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_GetEmployee"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pEmployeeId", employeeId);
                    conn.Open();

                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            employee.EmployeeId = long.Parse(reader["Employee_id"].ToString());
                            employee.Name = reader["Name"].ToString();
                        }
                    }
                    else
                        return null;

                    reader.Close();
                }
            }
            return employee;
        }

        public void Insert(Employee employee)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_InsertEmployee"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pName", employee.Name);

                    SqlParameter outParm = new SqlParameter();
                    outParm.Direction = ParameterDirection.Output;
                    outParm.ParameterName = "@poEmployeeID";
                    outParm.DbType = DbType.Int64;
                    command.Parameters.Add(outParm);

                    conn.Open();

                    command.ExecuteNonQuery();

                    employee.EmployeeId = long.Parse(command.Parameters["@poEmployeeID"].Value.ToString());
                }
            }
        }

        public void Update(Employee employee)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_UpdateEmployee"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pEmployeeID", employee.EmployeeId);
                    command.Parameters.AddWithValue("@pName", employee.Name);

                    conn.Open();

                    command.ExecuteNonQuery();

                }
            }
        }

        public void Delete(long employeeId)
        {
            using (SqlConnection conn = new SqlConnection(_config.GetConnectionString("DefaultDBConnection")))
            {
                using (SqlCommand command = new SqlCommand("usp_DeleteEmployee"))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection = conn;
                    command.Parameters.AddWithValue("@pEmployeeID", employeeId);

                    conn.Open();

                    command.ExecuteNonQuery();

                }
            }
        }
    }
}
