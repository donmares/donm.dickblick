﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DonM.DickBlick.Business.Contracts;
using DonM.DickBlick.Models;
using DonM.DickBlick.Web.ViewModels;
using Microsoft.AspNetCore.Http;

namespace DonM.DickBlick.Web.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(Business.Contracts.IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        public IActionResult Index()
        {
            return View(createViewModel(string.Empty));
        }

        private EmployeeViewModel createViewModel(string message)
        {
            var employees = _employeeService.GetAllEmployees().OrderBy(p => p.Name);

            var employeeViewModel = new EmployeeViewModel()
            {
                Employees = employees.ToList(),
                Message = message
            };
            return employeeViewModel;
        }

        [HttpPost]
        public IActionResult Create(EmployeeViewModel viewModel)
        {
            string message = "";
            if (ModelState.IsValid)
            {
                Employee employee = new Employee();
                employee.Name = viewModel.AddNew;
                _employeeService.Save(employee);
                message = employee.Name + " saved successfully.";
                viewModel.AddNew = "";
            }

            return View("Index", createViewModel(message));
        }

        [HttpPost]
        public IActionResult Update(long? id, string name)
        {
            string message = "";
            if (id.HasValue)
            {
                Employee employee = _employeeService.GetEmployee(id.Value);
                employee.Name = name;
                _employeeService.Save(employee);
                message = employee.Name + " updated successfully.";
            }

            return View("Index", createViewModel(message));
        }

        [HttpPost]
        public IActionResult Delete(long? id, string name)
        {
            string message = "";
            if (id.HasValue)
            {
                _employeeService.Delete(id.Value);
                message = name + " deleted successfully.";
            }
            return View("Index", createViewModel(message));
        }
    }
}