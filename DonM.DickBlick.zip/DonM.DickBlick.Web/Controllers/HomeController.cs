﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DonM.DickBlick.Business.Contracts;
using DonM.DickBlick.Models;
using DonM.DickBlick.Models.Enums;
using DonM.DickBlick.Web.ViewModels;
using System.IO;
using Microsoft.AspNetCore.Http;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace DonM.DickBlick.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly IProductService _productService;
        private readonly IEmployeeService _employeeService;
        public HomeController (IProductService productService, IEmployeeService employeeService)
        {
            _productService = productService;
            _employeeService = employeeService;
        }
        // GET: /<controller>/
        public IActionResult Index()
        {
            var products = _productService.GetAllProducts().OrderBy(p => p.Name);

            var homeViewModel = new HomeViewModel()
            {
                Title = "Welcome to Jim's Pencil Shop!",
                Products = products.ToList()
            };

            return View(homeViewModel);
        }

        public IActionResult Details(long id)
        {
            var product = _productService.GetProduct(id);
            if (product == null)
                return NotFound();

            return View(product);
        }

        public IActionResult Create()
        {
            var productViewModel = new ProductViewModel()
            {
                Product = null,
                Employees = _employeeService.GetAllEmployees()
            };

            return View(productViewModel);
        }

        [HttpGet]
        [HttpPost]
        public IActionResult Update(long id, string message)
        {
            IEnumerable<Product> AllProducts = _productService.GetAllProducts();
            if (id == 0)
                id = AllProducts.FirstOrDefault().ProductId;

            Product product = _productService.GetProduct(id);
            ProductViewModel productViewModel = new ProductViewModel()
            {
                Product = product,
                Employees = _employeeService.GetAllEmployees(),
                Products = AllProducts,
                ProductId = id,
                ImageUrlName = product.ImageUrl,
                ThumbnailUrlName = product.ImageThumbnailUrl,
                BuyerEmployeeID = product.Buyers.FirstOrDefault().EmployeeId
            };
            if (!string.IsNullOrEmpty(message))
                productViewModel.Message = message;

            return View(productViewModel);
        }

        [HttpPost]
        public IActionResult Delete(long id)
        {
            string name = _productService.GetProduct(id).Name;
            string message = name + " deleted successfully.";
            _productService.Delete(id);
            return RedirectToAction("Update", new {message=message});

        }

        [HttpPost]
        public async Task<IActionResult> Save(Product product, ProductViewModel viewModel, IFormCollection formCollection)
        {
            if (ModelState.IsValid)
            {
                if (viewModel.BuyerEmployeeID > 0)
                {
                    Employee employee = _employeeService.GetEmployee(viewModel.BuyerEmployeeID);
                    product.Buyers = new List<Employee> { employee };
                }

                Product originalProduct = new Product();
                if (formCollection.Keys.Contains("hdnProductId"))
                {
                    product.ProductId = long.Parse(formCollection["hdnProductId"]);
                    originalProduct = _productService.GetProduct(product.ProductId);
                    viewModel.ProductId = product.ProductId;
                }
                viewModel.ImageUrlName = product.ImageUrl = await SaveFile(viewModel.ImageUrl, originalProduct.ImageUrl);
                viewModel.ThumbnailUrlName = product.ImageThumbnailUrl = await SaveFile(viewModel.ThumbnailUrl, originalProduct.ImageThumbnailUrl);

                if (product.ImageUrl != null && product.ImageThumbnailUrl != null)
                {
                    ModelState["ImageUrlName"].Errors.Clear();
                    ModelState["ThumbnailUrlName"].Errors.Clear();
                    _productService.Save(product);
                }
            }
            viewModel.Product = product;
            viewModel.Employees = _employeeService.GetAllEmployees();
            viewModel.Products = _productService.GetAllProducts();
            viewModel.Message = product.Name + " saved successfully.";

            if (formCollection.Keys.Contains("hdnProductId"))
                return View("Update", viewModel);
            else
                return View("Create", viewModel);
        }

        private async Task<string> SaveFile(IFormFile formFile, string originalFileName)
        {
            string fileName = originalFileName;

            if (formFile != null && formFile.Length > 0)
            {
                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", formFile.FileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await formFile.CopyToAsync(stream);
                }
                fileName = Path.Combine("/images/", formFile.FileName);
            }

            return fileName;
        }

    }
}
