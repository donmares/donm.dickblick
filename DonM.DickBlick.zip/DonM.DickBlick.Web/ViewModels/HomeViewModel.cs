﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DonM.DickBlick.Models;

namespace DonM.DickBlick.Web.ViewModels
{
    public class HomeViewModel
    {
        public string Title { get; set; }
        public List<Product> Products { get; set; }
        public string Message { get; set; }
    }
}
