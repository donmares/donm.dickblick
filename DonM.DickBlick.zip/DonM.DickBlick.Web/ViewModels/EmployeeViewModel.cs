﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DonM.DickBlick.Models;
using System.ComponentModel.DataAnnotations;

namespace DonM.DickBlick.Web.ViewModels
{
    public class EmployeeViewModel
    {
        public List<Employee> Employees { get; set; }
        [Required]
        [StringLength(64, ErrorMessage = "Add New Naame is required")]
        public string AddNew { get; set; }

        public string Message { get; set; }

        public string UpdatedName { get; set; }
    }
}
