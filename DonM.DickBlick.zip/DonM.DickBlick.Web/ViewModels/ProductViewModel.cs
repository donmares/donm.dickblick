﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DonM.DickBlick.Models;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;
using DonM.DickBlick.Models.Enums;

namespace DonM.DickBlick.Web.ViewModels
{
    public class ProductViewModel
    {
        public long ProductId { get; set; }
        public Product Product { get; set; }
        public IEnumerable<Employee> Employees { get; set; }
        public IEnumerable<Product> Products { get; set; }
        [Required]
        [Range(0, long.MaxValue, ErrorMessage = "Buyer is required")]
        public long BuyerEmployeeID { get; set; }
        [Required]
        [StringLength(64, ErrorMessage = "ImageUrl is required")]
        public string ImageUrlName { get; set; }
        public IFormFile ImageUrl { get; set; }
        public IFormFile ThumbnailUrl { get; set; }
        [Required]
        [StringLength(64, ErrorMessage = "ThumbnailUrl is required")]
        public string ThumbnailUrlName { get; set; }
        public string Title { get; set; }
        public string Message { get; set; }
    }
}
