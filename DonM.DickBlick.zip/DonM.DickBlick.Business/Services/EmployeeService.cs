﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;
using DonM.DickBlick.Business.Contracts;
using DonM.DickBlick.Repos.Contracts;

namespace DonM.DickBlick.Business.Services
{
    public class EmployeeService : IEmployeeService
    {
        private IEmployeeRepo _repo;

        public EmployeeService(IEmployeeRepo repo)
        {
            _repo = repo;
        }

        public Employee GetEmployee(long employeeId)
        {
            return _repo.GetEmployeeById(employeeId);
        }

        public IEnumerable<Employee> GetAllEmployees()
        {
            return _repo.GetAllEmployees();
        }

        public void Save(Employee employee)
        {
            if (employee.EmployeeId == 0)
                _repo.Insert(employee);
            else
                _repo.Update(employee);
        }

        public void Delete(long employeeId)
        {
            _repo.Delete(employeeId);
        }
    }
}
