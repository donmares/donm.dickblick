﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;
using DonM.DickBlick.Business.Contracts;
using DonM.DickBlick.Repos.Contracts;

namespace DonM.DickBlick.Business.Services
{
    public class ProductService:IProductService 
    {
        private IProductRepo _repo;

        public ProductService(IProductRepo repo)
        {
            _repo = repo;
        }

        public Product GetProduct(long productId)
        {
            return _repo.GetProductById (productId);
        }

        public IEnumerable<Product > GetAllProducts()
        {
            return _repo.GetAllProducts();
        }

        public void Save(Product product)
        {
            if (product.ProductId==0)
                _repo.Insert(product);
            else
                _repo.Update(product);
        }

        public void Delete (long productId)
        {
            _repo.Delete(productId);
        }
    }
}
