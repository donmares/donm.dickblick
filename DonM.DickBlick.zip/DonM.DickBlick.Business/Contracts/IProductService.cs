﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;

namespace DonM.DickBlick.Business.Contracts
{
    public interface IProductService
    {
        IEnumerable<Product> GetAllProducts();
        Product GetProduct(long productId);
        void Save(Product product);
        void Delete(long productId);
    }
}
