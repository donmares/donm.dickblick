﻿using System;
using System.Collections.Generic;
using System.Text;
using DonM.DickBlick.Models;

namespace DonM.DickBlick.Business.Contracts
{
    public interface IEmployeeService
    {
        IEnumerable<Employee> GetAllEmployees();
        Employee GetEmployee(long employeeId);
        void Save(Employee employee);
        void Delete(long employeeId);
    }
}
